package com.example.EVIAppServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EviAppServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EviAppServerApplication.class, args);
	}

}
